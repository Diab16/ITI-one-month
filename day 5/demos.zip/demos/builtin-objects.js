// var fullName = "ali Ahmed";
// console.log(fullName.length);
// console.log(fullName.charAt(0));
// console.log(fullName.indexOf("w"));
// console.log(fullName.lastIndexOf("a"));
// console.log(fullName.substring(0, 7)); //0->6
// console.log(fullName.substring(2)); //0->6

// console.log(fullName.toLocaleUpperCase());
// console.log(fullName.toLocaleLowerCase());

// //math
// // console.log(Math.PI);
// console.log(Math.round(Math.random() * 10));

// Array
var numbers = [2, -1, 3, 44, 5, 6, 0, 3];
// var chars=['c','b','t','z','r','a']
var words = ["amira", "ali", "mohamed", "ramy"];
// console.log(numbers);
// console.log(numbers.join('/'));
// console.log(numbers.reverse());
// console.log(numbers.pop());
// console.log(numbers.pop());
// console.log(numbers.shift());
// console.log(numbers.unshift(90));
// console.log(numbers.push(88));
// console.log(numbers.sort());
// console.log(chars.sort());
// console.log(words.sort((a, b) => a - b));
// console.log(words);
// console.log(numbers);

//2=>val=2
//-1=>val=-1
//3=>val=3
// var element = numbers.find(function (val) {
//   if (val == 3) {
//     console.log("demo");
//     return val;
//   }
// });
// console.log(element);
// "amira"=>val
// ""ali""=>val
// "mohamed"=>val
// "ramy"=>val
// var result=words.filter(function(val){
//     if(val.charAt(0)=='a'){
//         // return val
//         // console.log(val)
//     }
// })

// console.log(result)

// var mixedarr=[3,"ali",true,[3,4,5]]
// console.log(mixedarr);

var arr1 = [3, 4, 5]; //address1
var arr2 = [3, 4, 5]; //address2
// spreed operator
// var arr3=
console.log(arr1[0] == arr2[0]);//true
console.log(arr1 == arr2);//false
