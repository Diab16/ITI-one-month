// console.log("hello js");

// var ,let,const

// var Name = "amira"; //function
// var name = "ali";
// let age = 18; //block scope
// const counter = 5;
// let lastName = "ramy";
// // counter=9
// console.log(age, name, counter);
// console.log(lastName);
// // console.log(x)

// function sum(x,y){
//     console.log(x+y)
// }

// var sum = function (x, y) {
//   console.log(x + y);
// };

// var sum = (x, y) => console.log(x + y);

// // var multiply = (x, y) => x * y;
// var multiply = (x) => x * 5;
// var multiply = (x) => {
//   x++;
//   return x * 5;
// };

// sum(7,3);
// sum();
// sum(4);
// sum(4,6,7,8);
// console.log(multiply(5, 6));
// console.log(multiply(5));

// *********
//global scope
// var x = 7;
// var y = 8;
// let w = 0;

// function sum() {
//   var x = 9;
//   var y = 5;
//   var z = 20;
//   let w = 70;
// //   console.log(z);
//   //local scope
//   return x + y;
// }
//20
//14
//7
//8

// console.log(sum());

// console.log(x)//7
// console.log(z)
// console.log(w)//

// var Name = "amira";
//var =>function scope
//let,const =>block scope
// if (Name == "amira") {
//     var lastName = "ali";
//     let age=29
//   console.log("is Equal");
// }
// {
//   var lastName = "ali";
//   let age=29
// }

// console.log(lastName);
// console.log(age)

// block scope{}//only let and const
// function scope function(){}//both let var and const result error

// Hoisting

// var y;
// let w = 0;
// let t;
// console.log(sum());
// console.log(y);
// console.log(w);
// console.log(t);
// console.log(p);

// function sum() {
//   var x = 9;
//   var y = 5;
//   return x + y;
// }

// console.log(w)
// console.log(u)
// let u=9
// var w=7

// *********
// var x = 7;
// var y = 9;
// var z=7
// console.log(++x);
// console.log(x / y);

// if (x == 7) {
//   console.log("equal");
// } else {
//   console.log("not equal");
// }

// x == 7 && y == 9 ? console.log("equal") : console.log("not equal");
// x == 7 && y == 9 ? console.log("equal") : console.log("not equal");

// let n = 100;

// (n >= 0) ? (n == 0 ? console.log("zero") : console.log("positive")) : console.log("negative");


// var x=5
// var y="5"
// var Name='amira'
// // console.log(x==y)//true =>value
// // console.log(x===y)//false =>value and type

// // console.log(x+y)//55=>concatination
// // console.log(y+Name)//55=>concatination
// var res=y+Name
// console.log(typeof res)//55=>concatination
// const expr = 'apple';
// switch (expr) {
//   case 'Oranges':
//     console.log('Oranges are $0.59 a pound.');
//     break;
//   case 'Mangoes':
//     console.log('Mangoes are $4.8 a pound.');
//     break;
//   case 'Papayas':
//     console.log('papayas are $2.79 a pound.');
//     // Expected output: "Mangoes and papayas are $2.79 a pound."
//     break;
//   default:
//     console.log(`Sorry, we are out of ${expr}.`);
// }

// Dialogue Boxes
// alert("hello welcome to my site")
// var userName=prompt("whats your name?")
// console.log(userName)
// var userAge= +prompt("whats your age?")
// var userAge=parseInt(prompt("whats your age?")) 
// console.log(typeof userAge);
// console.log(userAge);


var response = confirm('Are you sure you want to continue?');
console.log(response);